#include "chat.h"
#include "ui_chat.h"

chat::chat(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::chat)
{
    ui->setupUi(this);
    this->setWindowTitle("Chat room");
    ui->btnFileSendAll->setEnabled(false);
    ui->btnFileSendTo->setEnabled(false);
//    this->setMaximumSize(500, 400);
//    this->setMinimumSize(500,400);
    name = "";
    tcpClient = new QTcpSocket(this);

    connect(tcpClient, &QTcpSocket::connected, this, &chat::sendName);
    connect(tcpClient, &QTcpSocket::disconnected, this, &chat::canceled);
    connect(&timer, &QTimer::timeout, this, &chat::timerActions);

}

QString chat::getRandomString(int length)
{
    srand(QDateTime::currentMSecsSinceEpoch());

    const char ch[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    int size = sizeof(ch);

    char str[20];

    int num = 0;
    for (int i = 0; i < length; ++i)
    {
        num = rand() % (size - 1);
        str[i] = ch[num];
    }

    str[length] = 0;

    QString res(str);
    return res;
}

chat::~chat()
{
    delete ui;
}

void chat::timerActions() {
    timer.stop();
    sendData(toUser);
    ui->btnFileSendAll->setEnabled(false);
    ui->btnFileSendTo->setEnabled(false);
}

void chat::canceled() {
    tcpClient->disconnectFromHost();
    tcpClient->close();
}

void chat::closeEvent(QCloseEvent *event) {
    on_btnQuit_clicked();
}

void chat::sendName() {
    QByteArray arr = writeMsg("9", name, "");
    tcpClient->write(arr);
    qDebug() << "sendName";
    connect(tcpClient, &QTcpSocket::readyRead, this, &chat::readMsg);
}

QByteArray chat::writeMsg(const QString &type, const QString &name, const QString &msg){
    QJsonObject obj;
    obj.insert("type", type);
    obj.insert("name", name);
    obj.insert("msg", msg);
    QJsonDocument doc(obj);
    return doc.toJson();
}

QByteArray chat::writeFileHead(const QString &type, const QString &name,
                         const QString &sendFileName, const QString &sendFileSize){
    QJsonObject obj;
    obj.insert("type", type);
    obj.insert("name", name);
    obj.insert("fName", sendFileName);
    obj.insert("fSize", sendFileSize);
    QJsonDocument doc(obj);
    return doc.toJson();
}

void chat::readMsg() {
   QByteArray arr = tcpClient->readAll();
   DataInfo data;
   QJsonDocument doc = QJsonDocument::fromJson(arr);
   QJsonObject obj = doc.object();

   if(!doc.isObject()) {
       qint64 len = file.write(arr);
       recvSize += len;
       qDebug() << "recvSize: " << recvSize << " " << "fileSize " << fileSize;
       if (recvSize == fileSize) {
           file.close();
           ui->textBrowser->append("receved new file: " + fileName);
       }
       return;
   }

   data.type = obj.value("type").toString();

   if (data.type == "0") {
      QMessageBox::warning(this, QStringLiteral("Error"), QStringLiteral("Server is sending file"));
      file.close();
      ui->btnFileSendAll->setEnabled(false);
      ui->btnFileSendTo->setEnabled(false);
   }
   else if (data.type == "7") {
//       toUser = obj.value("name").toString();
       fileName = obj.value("fName").toString();
       fileSize = obj.value("fSize").toString().toInt();
       recvSize = 0;
       fileName = getRandomString(8) + fileName;
       file.setFileName(fileName);
       bool openOK = file.open(QIODevice::WriteOnly);
       if (!openOK) {
           toUser = "";
           qDebug() << "client write file error";
           QByteArray  arr = writeMsg("0", "", "");
       }
       return ;
   }
//   else if (data.type == "6") {
//       QByteArray msg = obj.value("msg").toString().toUtf8().data();
//       qint64 len = file.write(msg);
//       recvSize += len;
//       if (recvSize == fileSize) {
//           file.close();
//       }
//       return;
//   }
   data.name = obj.value("name").toString();
   data.msg = obj.value("msg").toString();
   qDebug() << "chat readMsg: " << data.type << " " << data.name << " " << data.msg;
   if (data.type == "1") {
       QVector<QString> userNames = data.msg.split(',');
       ui->listUsers->clear();
       for (int i = 0; i < userNames.size(); i++)
          ui->listUsers->addItem(userNames[i]);
       ui->listUsers->update();
       if (data.name == name) {
//           qDebug() << "readConnect : name = " << name;
           ui->labelName->setText(name);
           ui->labelName->adjustSize();
           ui->textBrowser->append("已经成功连接服务器\n");
           emit hi();
       }
   }else if (data.type == "2") {
        ui->textBrowser->append(data.msg.toUtf8().data());
   }else if (data.type == "3") {
       if (name == data.name)
           ui->textBrowser->append(data.msg.toUtf8().data());
   }else if (data.type == "4") {
       for(int i = 0; i < ui->listUsers->count(); i++) {
           if (ui->listUsers->item(i)->text() == data.name) {
               ui->listUsers->takeItem(i);
               break;
           }
       }
       if (data.name == name) {
           tcpClient->disconnectFromHost();
           tcpClient->close();
       }
//       otherUsers.remove(data.name);
   }else if (data.type == "8") {
       QMessageBox::warning(this, QStringLiteral("Error"), QStringLiteral("name is used"));
       tcpClient->disconnectFromHost();
       tcpClient->close();
       disconnect(tcpClient, 0, 0, 0);
//       tcpClient = new QTcpSocket(this);
       qDebug() << "chatRoom 8";
       exit(0);
       emit leave();

       return ;
   }


}

void chat::on_btnQuit_clicked()
{

//    this->hide();
    qDebug() << "下线了";
    QByteArray arr = writeMsg("4", name,"下线了");
    tcpClient->write(arr);
    tcpClient->flush();
//    tcpClient->disconnectFromHost();
//    tcpClient->close();
    emit leave();
}


void chat::on_btnSendAll_clicked()
{
    QTime current_time = QTime::currentTime();
    quint8 hour = current_time.hour();
    quint8 minute = current_time.minute();
    quint8 second = current_time.second();
    QString s = ui->textEdit->toPlainText();
    s = name + " " + QString::number(hour, 10) + ":" + QString::number(minute, 10)
          + ":" + QString::number(second) + "\n" + s;
    qDebug() << s;
    QByteArray arr = writeMsg("2", name, s);
    tcpClient->write(arr);
    tcpClient->flush();
}


void chat::on_btnSendTo_clicked()
{
    QString toUser = ui->leToUser->text().trimmed();
    if (toUser == ""){
       QMessageBox::warning(this, QStringLiteral("Error"), QStringLiteral("name is empty"));
       return;
    }

    if (toUser == name) {
       QMessageBox::warning(this, QStringLiteral("Error"), QStringLiteral("can not send to yourself"));
       return;
    }

    for (int i = 0; i < ui->listUsers->count(); i++) {
        if (ui->listUsers->item(i)->text() == toUser) {
            QTime current_time = QTime::currentTime();
            quint8 hour = current_time.hour();
            quint8 minute = current_time.minute();
            quint8 second = current_time.second();
            QString s = ui->textEdit->toPlainText();
            s = name + " " + QString::number(hour, 10) + ":" + QString::number(minute, 10)
                  + ":" + QString::number(second) + "\n" + s;
            qDebug() << s;
            QByteArray arr = writeMsg("3", toUser, s);
            tcpClient->write(arr);
            tcpClient->flush();
            return;
        }
    }
    QMessageBox::warning(this, QStringLiteral("Error"), QStringLiteral("no online user named this"));
}


void chat::on_btnChoose_clicked()
{
    QString filePath = QFileDialog::getOpenFileName(this, "Open file", "../");
    if (!filePath.isEmpty()) {
        fileName.clear();
        fileSize = 0;
        QFileInfo fileInfo(filePath);
        fileName = fileInfo.fileName();
        fileSize = fileInfo.size();
        sendSize = 0;

        file.setFileName(filePath);

        bool openOk = file.open(QIODevice::ReadOnly);
        if (!openOk) {
            qDebug() << "open file error";
        }

        ui->textEdit->append(filePath);
        ui->btnFileSendAll->setEnabled(true);
        ui->btnFileSendTo->setEnabled(true);

    }else {
        qDebug() << "file error";
        ui->btnFileSendAll->setEnabled(false);
        ui->btnFileSendTo->setEnabled(false);
    }
}

void chat::sendData(QString &toUser) {
    qDebug() << "fileName: " << fileName << " fileSize: " << fileSize;
    if (toUser == "") {

//        QByteArray arr = writeMsg("5", "", "");
//        qint64 emptySize = arr.size();
//        qDebug() << "sendData:" ;
//        qDebug() << "empty size : " << emptySize;

        qint64 len = 0;
        do{
            char buf[4 * 1024] = {0};
            len = 0;

            len = file.read(buf, sizeof(buf));
//            qDebug() << "file length: " << len;
//            arr = writeMsg("5", "", QString(buf));
//            qDebug() << "fileContent : " << arr;
//            len = tcpClient->write(arr);
            len = tcpClient->write(buf, len);
            qDebug() << "数据包大小：" << len;
//            len -= emptySize;
            sendSize += len;

        } while (len > 0);

        if (sendSize == fileSize) {
           QMessageBox::warning(this, QStringLiteral("OK"), QStringLiteral("File send successful !"));
           file.close();
        }

    }else {
//        QByteArray arr = writeMsg("6", toUser, "");

//        qint64 emptySize = arr.size();

        qint64 len = 0;
        do{
            char buf[4 * 1024] = {0};
            len = 0;

            len = file.read(buf, sizeof(buf));
//            arr = writeMsg("6", toUser, QString(buf));

//            len = tcpClient->write(arr);
//            len -= emptySize;
            len = tcpClient->write(buf, len);
            sendSize += len;
        } while (len > 0);
        toUser = "";
        if (sendSize == fileSize) {
           QMessageBox::warning(this, QStringLiteral("OK"), QStringLiteral("File send successful !"));
           file.close();
        }
    }
    ui->btnFileSendAll->setEnabled(false);
    ui->btnFileSendTo->setEnabled(false);
}

void chat::on_btnFileSendAll_clicked()
{
    QByteArray arr = writeFileHead("7", "", fileName, QString("%1").arg(fileSize));
    qint64 len = tcpClient->write(arr);
    if (len > 0) {
        timer.start(20);

    }else{
        qDebug() << "send file head error";
        file.close();
        ui->btnFileSendAll->setEnabled(false);
        ui->btnFileSendTo->setEnabled(false);
    }

}


void chat::on_btnFileSendTo_clicked()
{
    QString toUser = ui->leToUser->text().trimmed();
    if (toUser == ""){
       QMessageBox::warning(this, QStringLiteral("Error"), QStringLiteral("name is empty"));
       return;
    }

    if (toUser == name) {
       QMessageBox::warning(this, QStringLiteral("Error"), QStringLiteral("can not send to yourself"));
       return;
    }

    for (int i = 0; i < ui->listUsers->count(); i++) {
        if (ui->listUsers->item(i)->text() == toUser) {
            this->toUser = toUser;


            QByteArray arr = writeFileHead("7", toUser, fileName, QString("%1").arg(fileSize));
            qint64 len = tcpClient->write(arr);
            if (len > 0) {
                timer.start(20);

            }else{
                qDebug() << "send file head error";
                file.close();
                ui->btnFileSendAll->setEnabled(false);
                ui->btnFileSendTo->setEnabled(false);
            }
            return;
        }
    }
    QMessageBox::warning(this, QStringLiteral("Error"), QStringLiteral("no online user named this"));
}

