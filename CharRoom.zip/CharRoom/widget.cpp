#include "widget.h"
#include "ui_widget.h"


Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    connect(&subChat, &chat::hi, this,
            &Widget::showChat);
    connect(&subChat, &chat::leave, this, &Widget::quit);

}

Widget::~Widget()
{
    delete ui;
}

void Widget::showChat() {
    this->hide();
    subChat.show();
}
void Widget::on_btnLogin_clicked()
{
    subChat.name = ui->leName->text().trimmed();
    if (subChat.name == "") {
        QMessageBox::warning(this, QStringLiteral("Error!"), QStringLiteral("Please Enter name"), QMessageBox::Cancel);
        return;
    }
    QString ip = ui->leIP->text().trimmed();
//    quint16 port = ui->lePort->text().toInt();
    subChat.tcpClient->connectToHost(QHostAddress(ip), 8080);

}

void Widget::disconnected() {
    subChat.disconnect();
}

void Widget::quit() {
    qDebug() << "quit";
    subChat.hide();
    this->show();
}
