#ifndef CHAT_H
#define CHAT_H

#include <QWidget>
#include <QTcpSocket>
#include <QMessageBox>
#include <QTime>
#include <QSet>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QJsonArray>
#include <QCloseEvent>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QTimer>
#include <QDateTime>
#include <ctime>
#include "DataInfo.h"
namespace Ui {
class chat;
}

class chat : public QWidget
{
    Q_OBJECT

public:

    QString name;
    QSet<QString> otherUsers;

    explicit chat(QWidget *parent = nullptr);
    ~chat();
    void readMsg();
    void sendName();
    void canceled();
    void closeEvent(QCloseEvent *event);
    void sendData(QString &toUser);
    void timerActions();
    QByteArray writeMsg(const QString &type, const QString &name, const QString &msg);
    QByteArray writeFileHead(const QString &type, const QString &name,
                             const QString &sendFileName, const QString &sendFileSize);
    QString getRandomString(int length);
    QTcpSocket *tcpClient;

signals:
    void leave();
    void hi();

private slots:
    void on_btnQuit_clicked();

    void on_btnSendAll_clicked();

    void on_btnSendTo_clicked();

    void on_btnChoose_clicked();

    void on_btnFileSendAll_clicked();

    void on_btnFileSendTo_clicked();

private:
    Ui::chat *ui;
    QFile file;
    QString fileName;
    qint64 fileSize;
    qint64 sendSize;
    qint64 recvSize;
    QTimer timer;
    QString toUser;
};

#endif // CHAT_H
