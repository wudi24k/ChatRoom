#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpSocket>
#include "chat.h"
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

    void quit();
    void showChat();
    void disconnected();

private slots:
    void on_btnLogin_clicked();

private:
    Ui::Widget *ui;
    chat subChat;
    QTcpSocket *tcpClient;
};
#endif // WIDGET_H
