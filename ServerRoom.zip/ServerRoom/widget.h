#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QHash>
#include <QVector>
#include <QTime>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QJsonArray>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QTimer>

#include "DataInfo.h"
#include "sendfile.h"
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    void connectClient();
    void readMsg();
    void sendMsg(const QByteArray &s);
    QByteArray writeMsg(const QString &type, const QString &name, const QString &msg);
    QByteArray writeFileHead(const QString &type, const QString &name,
                             const QString &sendFileName, const QString &sendFileSize);
    void writeFileToAll(quint16 x);
    void writeFileToUser();
    void timerActions();
    void sendData();
    QString getRandomString(int length);
private slots:
    void on_btnSend_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Widget *ui;
    QTcpServer *tcpServer;
    QTcpSocket *tcpSocket;
    QVector<QTcpSocket*> clients;
    QHash<QString, quint16> users;
    QFile file;
    QString fileName;
    qint64 fileSize;
    qint64 sendSize;
    qint64 recvSize;
//    QTimer timer;
    QString toUser;
    bool isSending;
    QVector<SendFile*> sends;
};
#endif // WIDGET_H
