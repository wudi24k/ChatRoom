#ifndef SENDFILE_H
#define SENDFILE_H

#include <QObject>
#include <QTcpSocket>
#include <QTimer>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QJsonArray>
class SendFile : public QObject
{
    Q_OBJECT
public:
    explicit SendFile(QObject *parent = nullptr);
    explicit SendFile(QTcpSocket* tcp, QString fName, qint64 fSize, QObject *parent = nullptr);
    void sendData();
    void timerActions();
    void send();
    QByteArray writeFileHead(const QString &type, const QString &name,
                             const QString &sendFileName, const QString &sendFileSize);
//signals:


private:
    QTcpSocket* tcpSocket;
    QTimer timer;
    QFile file;
    QString fileName;
    qint64 fileSize;
    qint64 sendSize;
};

#endif // SENDFILE_H
