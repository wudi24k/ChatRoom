#include "sendfile.h"

SendFile::SendFile(QObject *parent)
    : QObject{parent}
{

}

SendFile::SendFile(QTcpSocket* tcp, QString fName, qint64 fSize, QObject *parent):QObject{parent} {
    tcpSocket = tcp;
    fileName = fName;
    file.setFileName(fName);
    sendSize = 0;
    fileSize = fSize;
    connect(&timer, &QTimer::timeout, this, &SendFile::timerActions);
}

void SendFile::sendData() {
    qDebug() << "timer ok";
    qint64 len = 0;
    do{
        char buf[4 * 1024] = {0};
        len = 0;

        len = file.read(buf, sizeof(buf));
//        arr = writeMsg("6", "", QString(buf));
        len = tcpSocket->write(buf, len);
        sendSize += len;

    } while (len > 0);

    if (sendSize == fileSize) {
//       QMessageBox::warning(this, QStringLiteral("OK"), QStringLiteral("File send successful !"));
       qDebug() << "file send successful";

    }
    qDebug() << "send data over";
    file.close();
}

void SendFile::send() {
    qDebug() << "open file before";
    qDebug() << file.fileName() << " " << fileName;
    bool openOK = file.open(QIODevice::ReadOnly);
    qDebug() << "open file after";
    if (!openOK) {
        qDebug() << "server open send file error";
        return;
    }
    QByteArray arr = writeFileHead("7", "", fileName, QString("%1").arg(fileSize));
    qDebug() << "send head before";
    qint64 len = tcpSocket->write(arr);
    qDebug() << "send head ok";
    if (len > 0) {
        sendSize = 0;
        timer.start(20);
    }else{
        qDebug() << "send file head error";
        file.close();
        tcpSocket = NULL;
    }
}

void SendFile::timerActions(){
    timer.stop();
    sendData();
}

QByteArray SendFile::writeFileHead(const QString &type, const QString &name,
                         const QString &sendFileName, const QString &sendFileSize){
    QJsonObject obj;
    obj.insert("type", type);
    obj.insert("name", name);
    obj.insert("fName", sendFileName);
    obj.insert("fSize", sendFileSize);
    QJsonDocument doc(obj);
    return doc.toJson();
}
