#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowTitle("服务器: 8080");
    tcpSocket = nullptr;
    tcpServer = new QTcpServer(this);
    tcpServer->listen(QHostAddress::Any, 8080);
    toUser = "";
    isSending = false;
    connect(tcpServer, &QTcpServer::newConnection,this, &Widget::connectClient);
//    connect(&timer, &QTimer::timeout, this, &Widget::timerActions);

}

Widget::~Widget()
{
    delete ui;
}

void Widget::timerActions() {
//    timer.stop();
    sendData();
}


QByteArray Widget::writeFileHead(const QString &type, const QString &name,
                         const QString &sendFileName, const QString &sendFileSize){
    QJsonObject obj;
    obj.insert("type", type);
    obj.insert("name", name);
    obj.insert("fName", sendFileName);
    obj.insert("fSize", sendFileSize);
    QJsonDocument doc(obj);
    return doc.toJson();
}

void Widget::sendData() {


//    QByteArray arr = writeMsg("6", "", "");
//    qint64 emptySize = arr.size();

    qint64 len = 0;
    do{
        char buf[4 * 1024] = {0};
        len = 0;

        len = file.read(buf, sizeof(buf));
//        arr = writeMsg("6", "", QString(buf));
        len = tcpSocket->write(buf, len);
        sendSize += len;

    } while (len > 0);

    if (sendSize == fileSize) {
//       QMessageBox::warning(this, QStringLiteral("OK"), QStringLiteral("File send successful !"));
       qDebug() << "file send successful";
       file.close();
    }
    qDebug() << "send data over";
    tcpSocket = NULL;

}

void Widget::connectClient() {
    tcpSocket = tcpServer->nextPendingConnection();
    QString ip = tcpSocket->peerAddress().toString();
    quint16 port = tcpSocket->peerPort();
    QString s = QString("[%1:%2]: 尝试连入\n").arg(ip).arg(port);
    ui->textBrowser->append(s);
    clients.emplace_back(tcpSocket);
    connect(tcpSocket, &QTcpSocket::readyRead,this, &Widget::readMsg);
}


QByteArray Widget::writeMsg(const QString &type, const QString &name, const QString &msg){
    QJsonObject obj;
    obj.insert("type", type);
    obj.insert("name", name);
    obj.insert("msg", msg);
    QJsonDocument doc(obj);
    return doc.toJson();
}

void Widget::writeFileToAll(quint16 x) {
//    QVector<QFile> files;
//    QFile f;
//    for (int i = 0; i < clients.size(); i++) {
//        files.emplace_back(f);
//    }

    for (int i = 0; i < sends.size(); i++) {
        delete sends[i];
    }
    sends.clear();

    for (int i = 0; i < clients.size(); i++){
        SendFile *sd = new SendFile(clients[i], fileName, fileSize);
        sends.emplace_back(sd);
    }
    for (int i = 0; i < clients.size(); i++) {

        if (i == x) {
            continue;
        }else {
            qDebug() << i << " start";
//            files[i].setFileName(fileName);
//            bool openOK = files[i].open(QIODevice::ReadOnly);
//            if (!openOK) {
//                qDebug() << "server open send file error";
//                return;
//            }
//            tcpSocket = clients[i];
//            QByteArray arr = writeFileHead("7", "", fileName, QString("%1").arg(fileSize));
//            qint64 len = tcpSocket->write(arr);
//            if (len > 0) {
//                sendSize = 0;
//                timer.start(20);

//            }else{
//                qDebug() << "send file head error";
//                f.close();
//                tcpSocket = NULL;
//            }

            sends[i]->send();
            qDebug() << i << " end";
        }
    }
    isSending = false;

}
void Widget::writeFileToUser() {

//    bool openOK = file.open(QIODevice::ReadOnly);
//    if (!openOK) {
//        qDebug() << "server open send file error";
//        return;
//    }
//    tcpSocket = clients[users[toUser]];
//    QByteArray arr = writeFileHead("7", "", fileName, QString("%1").arg(fileSize));
//    qint64 len = tcpSocket->write(arr);
//    if (len > 0) {
//        sendSize = 0;
//        timer.start(20);
//    }else{
//        qDebug() << "send file head error";
//        file.close();
//        tcpSocket = NULL;
//    }
//    tcpSocket = NULL;
    for (int i = 0; i < sends.size(); i++) {
        delete sends[i];
    }
    sends.clear();
    SendFile *s = new SendFile(clients[users[toUser]], fileName, fileSize);
    sends.emplace_back(s);
    sends.back()->send();
    isSending = false;
}

QString Widget::getRandomString(int length)
{
    srand(QDateTime::currentMSecsSinceEpoch());

    const char ch[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    int size = sizeof(ch);

    char str[20];

    int num = 0;
    for (int i = 0; i < length; ++i)
    {
        num = rand() % (size - 1);
        str[i] = ch[num];
    }
    str[length] = 0;

    QString res(str);
    return res;
}

void Widget::readMsg() {

    for (int i = 0; i < clients.size(); i++) {
        if (clients[i]->bytesAvailable() > 0) {
            QByteArray arr = clients[i]->readAll();
            qDebug() << "服务端接受数据 ：" << arr;
            DataInfo data;
            QJsonDocument doc = QJsonDocument::fromJson(arr);

            if(!doc.isObject()) {
                qint64 len = file.write(arr);
                recvSize += len;
                qDebug() << "recvSize: " << recvSize << " " << "fileSize " << fileSize;
                if (recvSize == fileSize) {
                    file.close();
                    if (toUser == "")
                        writeFileToAll(i);
                    else
                        writeFileToUser();
                }
                continue;
            }

            QJsonObject obj = doc.object();
            data.type = obj.value("type").toString();
            qDebug() << "isobj " << doc.isObject();
            qDebug() << "isArray" << doc.isArray();
            qDebug() << "message: type" << data.type;
            if (data.type == "7") {

                if (isSending) {
                    arr = writeMsg("0", "", "server is sending");
                    clients[i]->write(arr);
                }else {
                    toUser = obj.value("name").toString();
                    fileName = obj.value("fName").toString();
                    fileSize = obj.value("fSize").toString().toInt();
                    recvSize = 0;
                    fileName = getRandomString(8) + fileName;
                    qDebug() << "书写文件名为： " << fileName;
                    file.setFileName(fileName);
                    bool openOK = file.open(QIODevice::WriteOnly);
                    if (!openOK) {
                        toUser = "";
                        qDebug() << "server write file error";
                        arr = writeMsg("0", "", "server write file error");
                        clients[i]->write(arr);
                        isSending = false;
                        continue;
                    }
                    isSending = true;
                }
                continue;
            }

//            else if (data.type == "5") {

//                QByteArray msg = obj.value("msg").toString().toUtf8().data();
//                qDebug() << "文件内容：" << msg;

//                qint64 len = file.write(msg);

//                recvSize += len;
//                qDebug() << "recvSize : " << recvSize << " 写入文件大小:" << len;
//                qDebug() << "文件大小" << fileSize;
//                if (recvSize == fileSize) {
//                    file.close();
//                    writeFileToAll(i);
//                }
//                continue;
//            } else if (data.type == "6") {
//                QByteArray msg = obj.value("msg").toString().toUtf8().data();
//                qint64 len = file.write(msg);
//                recvSize += len;
//                if (recvSize == fileSize) {
//                    file.close();

//                    writeFileToUser();
//                }
//                continue;
//            }

            data.name = obj.value("name").toString();
            data.msg = obj.value("msg").toString();
//            qDebug() << "type : " << data.type << "name " << data.name << " " << data.msg;
            if (data.type == "1" || data.type == "2") {
                sendMsg(arr);
            }else if (data.type == "3") {
                clients[users[data.name]]->write(arr);
            }else if (data.type == "9") {
                if (users.contains(data.name)) {
                    arr = writeMsg("8", "", "");
                    tcpSocket->write(arr);
//                    tcpSocket->disconnectFromHost();
//                    tcpSocket->close();
                    clients.pop_back();
                    continue;
                }

                QString ip = tcpSocket->peerAddress().toString();
                quint16 port = tcpSocket->peerPort();
                QString str = QString("[%1:%2]: 连入成功\n").arg(ip).arg(port);
                ui->textBrowser->append(str);


                users[data.name] = clients.size() - 1;

                QString userNames = "";
                for (auto it = users.constBegin() ; it != users.constEnd(); it++)
                    userNames += it.key() + ",";
                arr = writeMsg("1", data.name, userNames);
                for (int i = 0; i < clients.size(); i++)
                    clients[i]->write(arr);
//                qDebug() << "readName: " << arr;
            } else if (data.type == "4") {
//                qDebug() << "remove key";
                QTcpSocket* tmp = clients[users[data.name]];
                clients[users[data.name]] = clients.back();
                tmp->disconnectFromHost();
                tmp->close();
                clients.pop_back();
                users.remove(data.name);
//                for (auto it=users.begin(); it != users.end(); it++){
//                    qDebug() << it.key();
//                }
//                qDebug() << "hello";

                sendMsg(arr);
            }
            ui->textBrowser->append(arr);

        }
    }

}

void Widget::sendMsg(const QByteArray &s) {
    for (int i = 0; i < clients.size(); i++) {
        clients[i]->write(s);
    }
}

void Widget::on_btnSend_clicked()
{
//    if (tcpSocket == nullptr)
//        return;

//    QString s = ui->textEdit->toPlainText();
//    tcpSocket->write(s.toUtf8().data());
}


void Widget::on_pushButton_2_clicked()
{
//    if (tcpSocket == nullptr)
//        return ;
//    tcpSocket->disconnectFromHost();
//    tcpSocket->close();
//    tcpSocket = nullptr;
}

