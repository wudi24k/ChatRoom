#ifndef DATAINFO_H
#define DATAINFO_H
#include <QString>

struct DataInfo {
    QString type;
    QString name;
    QString msg;
};

#endif // DATAINFO_H
